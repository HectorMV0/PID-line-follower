function PID_Controller()   
%% initialization
    clc
    s=1;                                                            % factor de escala
    nLinVel=0.15;                                                   % velocidad normal de las ruedas
    disp('Program started');
    sim=remApi('remoteApi');                                        % Conexión al archivo del prototipo 
    sim.simxFinish(-1);                                             % Cerrar conexiones existentes
    clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);     % Conexión al Localhost
    if (clientID>-1)                                                %Comprobar si la conexión fue existosa
        disp('Connected to remote API server');    
    else
        disp('Failed connecting to remote API server');
    end
    
    if clientID>-1                                                  % Sólo si la conexión fue exitosa
        %%  Now try to retrieve handlers in a blocking fashion 
        [joint_handler, sensor_handler, base_handler] = get_handlers(sim, clientID);    %Obtener handlers
        disp('Joint handles acquired')     
        pause(2);
        %% Control Loop
        % initial values for control
        LinVelLeft = nLinVel*s;                                     %Velocidad normal derecha
        LinVelRight = nLinVel*s;                                    %Velocidad normal izquierda
        Vel_ini=[LinVelLeft,LinVelRight];                           %Vector de velocidades
        % test if sensors can be read
        disp('leyendo sensores')
        n=1;
        base_pos=zeros(1,3);                                        %Vector de posición 
        I=zeros(1,3);      
        [sensors, base_pos(n,:)] = get_data_sensor(sim, clientID,sensor_handler, base_handler,1);       %Leer sensores y posición 
        t = clock;                                                  %Tiempo real 
        info_sensores=[sensors(1) sensors(2) sensors(3)];
        %         disp(base_pos)
        startTime = t(5)*60 + t(6);                                 %Tiempo de inicio en segundos
        currentTime = t(5)*60 + t(6);                               %Tiempo actual en segundos
        T_final = 30;                                               %Tiempo de simulación
        T = 0.01;                                                   %Tamaño de paso
        ek = [0, 0, 0];                                             %Vector para el error 
        kp = 0.028;          
        ki = 0.03;
        kd = 0.000002;                                            %Constante derivativo
%       kp = 0.0095;          
%       ki = 0.02;
%       kd = 0.00003;
%       d = 2*T;                                    
%       a = 2*kp*T+ki*(T^2)+4*kd;
%       b = 2*ki*(T^2)-8*kd;
%       c = ki*(T^2)-2*kp*T+4*kd;
        u = ones(2,2).*Vel_ini(1)/2;                                %Matriz u de velocidad de motores
        T0=0;
        
        while (currentTime-startTime < T_final)                     %Mientras el tiempo transurrido sea menor al tiempo de simulación
            if currentTime-T0>T                                     %Si el tiempo actual es mayor al paso
                t = clock; 
                T0=t(5)*60 + t(6);
                [sensors, base_pos(n,:)] = get_data_sensor(sim, clientID,...
                    sensor_handler, base_handler, 0);               %Obtener información de los sensores
                info_sensores=[info_sensores; sensors(1) sensors(2) sensors(3)];
                % data proccessing
                k = 3;
                ek(:,k) = decision2(sensors);                       %Definir error en el camino 
                [u(:,k)] = control(ek,u,I,kp,ki,kd,T);              %Aplicar control PID
                % send data
                send_motors(sim,clientID, joint_handler, u(:,k));   %Mandar ajuste de velocidad a los motores
                
                % rotate samples
                
                ek = rotation(ek);                                  %Recorrer valores de error hacia la izquierda
                I=rotation(I);
                n=n+1;                                              %Aumentar contador
            end
            t=clock;                                                %Actualizar tiempo
            currentTime= t(5)*60 + t(6);
            
        end
        send_motors(sim,clientID, joint_handler, [0,0]);
        %% Make sure that the last command sent out had time to arrive.
        sim.simxGetPingTime(clientID);
        % Now close the connection to CoppeliaSim:    
        sim.simxFinish(clientID);
    end
    sim.delete(); % call the destructor!
    save('PID_Controller_camino3.mat','base_pos')
    save('sensores_3.mat','info_sensores')
    disp('Program ended');
end
%% API functions
function send_motors(sim,clientID, joint_handlers, velocity)
    s=1;        % scale factor
    wheelRadius=0.027;
    interWheelDistance=0.119;
    joint_dyn_left = joint_handlers{1};
    joint_dyn_right = joint_handlers{2};
    [returnCode]=sim.simxSetJointTargetVelocity(clientID, joint_dyn_left...
        ,velocity(1)/(s*wheelRadius), sim.simx_opmode_oneshot);
    [returnCode]=sim.simxSetJointTargetVelocity(clientID, joint_dyn_right...
        ,velocity(2)/(s*wheelRadius), sim.simx_opmode_oneshot);
    sim.simxAddStatusbarMessage(clientID,['recieved: ' num2str(velocity(1)) ' , ' num2str(velocity(2))]...
            ,sim.simx_opmode_oneshot);
end

function [joints, sensors, base] = get_handlers(sim, clientID)
    [returnCode, joint_dyn_left]=sim.simxGetObjectHandle(clientID...
        ,'DynamicLeftJoint', sim.simx_opmode_blocking);
    [returnCode, joint_dyn_right]=sim.simxGetObjectHandle(clientID...
        ,'DynamicRightJoint', sim.simx_opmode_blocking); 
    [returnCode, leftSensor]=sim.simxGetObjectHandle(clientID...
        ,'LeftSensor', sim.simx_opmode_blocking);
    [returnCode, middleSensor]=sim.simxGetObjectHandle(clientID...
        ,'MiddleSensor', sim.simx_opmode_blocking);
    [returnCode, rightSensor]=sim.simxGetObjectHandle(clientID...
        ,'RightSensor', sim.simx_opmode_blocking);
    [returnCode, base]=sim.simxGetObjectHandle(clientID...
        ,'LineTracerBase', sim.simx_opmode_blocking);
    sim.simxAddStatusbarMessage(clientID,'Handles recieved'...
            ,sim.simx_opmode_oneshot);
    joints = {joint_dyn_left, joint_dyn_right};
    sensors = {leftSensor, middleSensor, rightSensor};
end

function [sensors, base_pos] = get_data_sensor(sim, clientID, handlers,...
    base_handler, first)
    if first
        mode=sim.simx_opmode_streaming;  % first time executed
    else
        mode=sim.simx_opmode_buffer;
    end
    sensors = [0; 0; 0];
    leftSensor = handlers{1};
    middleSensor = handlers{2};
    rightSensor = handlers{3};
    [returnCode, sensors(1)]=sim.simxReadVisionSensor(clientID,...
        leftSensor, mode);
    [returnCode, sensors(2)]=sim.simxReadVisionSensor(clientID,...
        middleSensor, mode);
    [returnCode, sensors(3)]=sim.simxReadVisionSensor(clientID,...
        rightSensor, mode);
    [returnCode, base_pos]=sim.simxGetObjectPosition(clientID,...
        base_handler, -1, mode);
end

%% Control functions
function [error]=decision2(sensor)
    if (sensor(1)==1 && sensor(2)==0 && sensor(3)==1)
        err = 0;
        factor = 0;
    else 
        err = 1;
        if (sensor(1)==1 && sensor(3)==0)
            factor = 1;
        elseif (sensor(3)==1 && sensor(1)==0)
            factor = -1;
        else
            factor = -2; %search path
        end
    end
    error = err*factor;
end

function sigp = rotation(signal)
    [m,n] = size(signal);
    sigp = zeros(m,n);
    sigp(:,1:end-1) = signal(:,2:end);
end