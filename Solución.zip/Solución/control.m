function [uout] = control( ek,u,I,Kp,Ki,Kd,T)

    uout = zeros(2,1);
    P=ek(1,end);
    I(1,end)=I(1,end-1)+ek(1,end)*T;
    D=(ek(1,end)-ek(1,end-1))*T;
    
    PID=(Kp*P)+(Ki*I(1,end))+(Kd*D);
    
    uout(1)=u(1)+PID;
    uout(2)=u(2)-PID;
    
end